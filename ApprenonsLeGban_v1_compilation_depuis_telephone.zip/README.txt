APPRENONS LE GBAN — projet Android source (version 1.0)

CONTENU
- Rubrique Animaux : 10 mots fournis par le porteur du projet.
- Rubrique Les 12 mois : traductions fournies par le porteur du projet.
- Quiz de révision.
- Lecture audio en français uniquement via la synthèse vocale Android.
- Fonction copier pour les mots Gban.

IMPORTANT
Ce dossier est un projet Android Studio prêt à être compilé, mais ce n'est pas encore un fichier APK installable.
L'environnement de création utilisé ici ne dispose pas du SDK Android ni de Gradle pour produire et tester un APK signé.
Les sons Gban ne sont pas générés automatiquement : il faudra intégrer des enregistrements validés par des locuteurs Gban.

POUR OBTENIR L'APK
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier ApprenonsLeGbanAndroid.
3. Laisser Android Studio synchroniser Gradle.
4. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
5. L'APK de test sera créé dans app/build/outputs/apk/debug/.

L'application fonctionne hors connexion une fois installée.


COMPILATION À DISTANCE DEPUIS UN TÉLÉPHONE (SANS PC)
Cette version contient un workflow GitHub Actions pour demander la compilation dans le cloud.
1. Depuis le navigateur du téléphone, créer un compte GitHub si nécessaire.
2. Créer un nouveau dépôt (repository) et le nommer Apprenons-Le-Gban.
3. Extraire le ZIP, puis téléverser tous les fichiers et dossiers du projet dans le dépôt
   en conservant notamment le dossier .github/workflows.
4. Ouvrir l'onglet Actions du dépôt. Autoriser les workflows si GitHub le demande.
5. Choisir "Build Android APK", puis "Run workflow" si la compilation ne démarre pas automatiquement.
6. Lorsque l'exécution est terminée avec succès, ouvrir cette exécution, descendre à Artifacts
   et télécharger "Apprenons-Le-Gban-debug-apk".
7. Extraire l'archive téléchargée pour récupérer app-debug.apk, puis l'ouvrir sur le téléphone.
Android peut demander d'autoriser l'installation depuis le navigateur ou le gestionnaire de fichiers.

IMPORTANT : il s'agit d'un APK debug de test, pas d'une version signée pour publication sur Google Play.
